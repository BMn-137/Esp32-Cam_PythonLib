#from everywhereml.tests.preprocessing.MinMaxScalerTest import *
from everywhereml.tests.preprocessing.image import *